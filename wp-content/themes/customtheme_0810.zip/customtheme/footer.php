<footer>
    <div class="inner">
        <div class="ft-txtgp">
            <div class="txt-leftgp">
                <h2>JaDoo</h2>
                <p>Lorem ipsum dolor sit amet,Stet clita kasd gubergren, no sea takimata sanctus est is the is the magna
                    aliquyam.</p>
            </div>
            <div class="txt-rightgp">
                <p>We are digital designer living in United States. <br>Apart from eating burger</p>
                <div class="social-gp">
                    <div class="social-list">
                        <h3>SENT MAIL</h3>
                        <p>info@portfolio.com<br>career.portfolio.com</p>
                    </div>
                    <div class="social-list">
                        <h3>MAKE CALL</h3>
                        <p>+123 456 7890<br>+123 456 7890</p>
                    </div>
                    <div class="social-list">
                        <h3>GET IN TOUCH</h3>
                        <p>123/A, Hamburger City<br>New York, USA</p>
                    </div>
                </div>
            </div>
        </div>
        <p class="copyright">2022 All Rights Reserved</p>
    </div>
    <a href="#" class="btn-top"><img src="<?php echo  bloginfo('template_directory');?>/image/ico_top.png" alt=""></a>
</footer>
<?php wp_footer(); ?>
</body>

</html>